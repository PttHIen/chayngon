<?php

class PusherAppController extends AppController {

}

