<?php

class PusherAppModel extends AppModel {

}

